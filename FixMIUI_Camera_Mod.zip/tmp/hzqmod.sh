#!/sbin/sh

bp="/system/build.prop"

busybox mount /system

#HZQ - 2017-03-22 : (for a better uninstaller)
#    At 1st run, backup current build.prop to build.prop.hzq
#    Restore the original build.prop (if exist) before flashing
if [ -f /system/build.prop.hzq ]; 
  then
    rm -rf $bp
    cp $bp.hzq $bp
  else
    cp $bp $bp.hzq
fi

#HZQ - 2017-05-19 : New line, some build.prop doesn't have a blank line at the bottom of the file
echo "" >> $bp

for mod in misc;
  do
    for prop in `cat /tmp/$mod`;do
      export newprop=$(echo ${prop} | cut -d '=' -f1)
      sed -i "/${newprop}/d" /system/build.prop
      echo $prop >> /system/build.prop
    done
done

